//
//  ProgressView.swift
//  Meu App
//
//  Created by Isadora Cristina on 04/02/25.
//
import SwiftUI

struct ProgressBar: View {
    
    @State var percent: CGFloat = 0
    @State var imageBell = Image("nivel1completo")
    @State var imageRecado = Image("recado1")
    @State var imageProgressBar = Image("barradeprogresso1")
    @State var text = ""
    @State var title = ""
    @State var showIHAD = false
    @State var showGameGesture1 = false
    @State var tapText = ""
    
    var width: CGFloat = 30
    var height: CGFloat = 345
    var color1 = Color(.laranja1)
    var color2 = Color(.rosa)
    var fase: fases
    
    @State  var isNextLevel: Bool = false
    
    let shared = AudioManager.shared
    
//    func registerFont() {
//            guard let fontURL = Bundle.main.url(forResource: "Alkatra-Bold", withExtension: "ttf"),
//                  let fontDataProvider = CGDataProvider(url: fontURL as CFURL),
//                  let font = CGFont(fontDataProvider) else {
//                fatalError("Erro ao carregar a fonte")
//            }
//
//            var error: Unmanaged<CFError>?
//            if !CTFontManagerRegisterGraphicsFont(font, &error) {
//                print("Erro ao registrar a fonte: \(error!.takeRetainedValue())")
//            }
//        }
    
    
    var body: some View {
        let multiplier = height / 100
        ZStack {
            Color(.fundo1)
                .ignoresSafeArea()
               
            
            HStack {
//                    aqui ok
                VStack(alignment: .leading){
                            Text(title)
                                .foregroundColor(Color("letras"))
                                .font(.system(size: 28, weight: .bold, design: .rounded))
                                .frame(width:612, height: 38, alignment: .leading)
                                
                 
                        
                        Text(text)
                            .foregroundColor(Color("letras"))
                            .font(.system(size: 18, weight: .regular, design: .rounded))
                            .frame( width: 294, height: 101, alignment: .topLeading)
//
                      imageRecado
                            .resizable()
                            .frame(width: 293, height: 111)
//                            .padding(.bottom, 20)
                    
                    
                    Text(tapText)
                        .foregroundColor(Color("letras"))
                        .font(.system(size: 18, weight: .light, design: .rounded))
                    
//                        .padding(.bottom, -30)
                    
                        if fase == .fase3 {
                            HStack(spacing:40) {
                                //colocar botão- restart/play again
                                Button(action: {
                                    showIHAD = true
                                }) {
                                    Image("buttonHome")
                                        .resizable()
                                        .frame(width: 128, height: 54)
                                }
                                .fullScreenCover(isPresented: $showIHAD) {
                                    IHAD()
                                }
                                
                                Button(action: {
                                    showGameGesture1 = true
                                }) {
                                    Image ("buttonPlayAgain")
                                        .resizable()
                                        .frame(width: 128, height: 54)
                                }
                                .fullScreenCover(isPresented: $showGameGesture1) {
                                    GameGesture1(roundTime: 10)
                                }
                            }
                            .padding(.top, 20)
                            .onAppear {
                                shared.playSoundRepeat(named: "Nivel1.wav")
                            }
                        }
                } .padding(.leading, 30)
                  .padding (.top,30)
                
                    //MARK: Imagem porcetagem e barra de progresso
                    // aqui ok
                HStack(spacing:-11) {
                    
                        imageProgressBar
                            .resizable()
                            .frame(width: 113, height: 350)
//                            .padding(.top, 25)
                        
                        
                        ZStack (alignment: .bottom) {
                            RoundedRectangle (cornerRadius: height, style: .continuous)
                                .frame(width: width, height: height)
                                .foregroundColor(Color.black.opacity(0.1))
                            
                            RoundedRectangle (cornerRadius: height, style: .continuous)
                                .frame(width: width, height: percent * multiplier)
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [color1, color2]), startPoint: .bottom, endPoint: .top)
                                        .clipShape(RoundedRectangle(cornerRadius: height, style: .continuous))
                                )
                                .animation(.linear, value:percent)
                                .foregroundColor(.clear)
                            
                        } /*.padding(.top,30)*/
                } .padding(.top,30)
                
//                .ignoresSafeArea(edges: .trailing)
//                .padding(.trailing, 0.5)
            }
            
                imageBell
                    .resizable()
                    .frame(width: 303, height: 350)
                    .ignoresSafeArea()
                    .padding(.top, 112)
                    .padding(.leading,200)
//                    .border(.red, width: 3)
            
        }
        .contentShape(Rectangle())
        .onAppear {
            getCurrentPercent()
          
        }
        .onTapGesture {
            if !(fase  == .fase3) {
                isNextLevel = true
            }
        }
        .fullScreenCover(isPresented: $isNextLevel, content: {
            if fase == .fase1 {
                GameGesture2( roundTime:10)
            } else if fase == .fase2 {
                GameShake( roundTime: 5)
            }
        })

    }
    
    func getCurrentPercent () {
        if fase == .fase1 {
            percent = 25
            text = "Lifting the hair roots is essential to give more lightness to the curls, preventing them from sticking together!"
            print("fase: \((fase))")
            title = "Incredible! You have completed the first task!!"
            tapText = "Tap the screen to continue"
           
        } else if fase == .fase2 {
            percent = 75
            text = "Adding volume to curly hair enhances its natural shape, making the look more vibrant and lively!"
            imageBell = Image("nivel2completo")
            title = "Great! You have completed the second task!!"
            imageProgressBar = Image ("barradeprogresso2")
            tapText = "Tap the screen to continue"
            imageRecado = Image("recado2")
            
        } else if fase == .fase3 {
            percent = 100
            text = "My hair is full of volume, free, and vibrant, reflecting my strength and identity with confidence and pride..."
            imageBell = Image("nivel3completo")
            title = "Woohoo, you did it!!"
            imageRecado = Image("recado3")
            imageProgressBar = Image ("barradeprogresso3")
            //            tapText = "Tap the screen to continue"
        }
        else {
            percent =  0
        }
    }
}
//
//#Preview {
//    ProgressBarfase: .fase1)
//    
//}

